def get_user_code():
    code = input("Enter user code: ")  # keypad
    return code
