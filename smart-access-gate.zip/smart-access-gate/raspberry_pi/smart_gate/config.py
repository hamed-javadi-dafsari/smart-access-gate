SERIAL_PORT = "/dev/ttyUSB0"
BAUDRATE = 9600

DB_PATH = "access_log.db"
VIDEO_DURATION = 30  # seconds

CAMERA_URL = "rtsp://user:pass@192.168.1.100/Streaming/Channels/101"
